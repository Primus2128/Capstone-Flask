from flask import Flask, render_template, request, redirect, session, flash
import psycopg2
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database configuration
DB_NAME = "day12_assignment"
DB_USER = "postgres"
DB_PASS = "root"
DB_HOST = "localhost"
DB_PORT = "5432"

# Connect to PostgreSQL
def get_db_connection():
    conn = psycopg2.connect(
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASS,
        host=DB_HOST,
        port=DB_PORT
    )
    return conn

# Route for registration
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        employee_id = request.form['employee_id']
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='sha256')

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO employees (employee_id, username, password) VALUES (%s, %s, %s)",
                           (employee_id, username, hashed_password))
            conn.commit()
            flash('Registration successful! Please log in.')
            return redirect('/login')
        except psycopg2.errors.UniqueViolation:
            flash('Employee ID or Username already exists.')
            conn.rollback()
        finally:
            cursor.close()
            conn.close()

    return render_template('register.html')

# Route for login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        employee_id = request.form['employee_id']
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM employees WHERE employee_id = %s AND username = %s", (employee_id, username))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user and check_password_hash(user[3], password):  # Adjusted index for password column
            session['user_id'] = user[0]
            session['employee_id'] = user[1]
            session['username'] = user[2]
            flash('Login successful!')
            return redirect('/dashboard')
        else:
            flash('Login failed. Check your employee ID, username, and/or password.')

    return render_template('login.html')

# Route for dashboard
@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return f"Hello, {session['username']} (Employee ID: {session['employee_id']})! Welcome to your dashboard."
    else:
        return redirect('/login')

# Route for logout
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('employee_id', None)
    session.pop('username', None)
    flash('You have been logged out.')
    return redirect('/login')

if __name__ == '__main__':
    app.run(debug=True)
